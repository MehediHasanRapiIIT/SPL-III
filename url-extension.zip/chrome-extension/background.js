chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.action === "checkURL") {
        checkPhishingStatus(request.url)
            .then(result => sendResponse(result))
            .catch(error => sendResponse({error: error.message}));
        return true; // Required to use sendResponse asynchronously
    }
});

async function checkPhishingStatus(url) {
    try {
        const response = await fetch('http://localhost:5000/predict', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({url: url})
        });

        if (!response.ok) {
            throw new Error(`Server returned ${response.status}`);
        }

        return await response.json();
    } catch (error) {
        console.error('Phishing check failed:', error);
        return {error: "Couldn't connect to detection service"};
    }
}