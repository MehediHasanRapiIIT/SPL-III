document.addEventListener('DOMContentLoaded', function() {
    const checkBtn = document.getElementById('checkBtn');
    const urlInput = document.getElementById('urlInput');
    const resultDiv = document.getElementById('result');
    
    // Auto-fill current URL when popup opens
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        if (tabs[0] && tabs[0].url) {
            urlInput.value = tabs[0].url;
        }
    });

    checkBtn.addEventListener('click', function() {
        const url = urlInput.value.trim();
        if (!url) {
            resultDiv.textContent = "Please enter a URL";
            resultDiv.className = "error";
            return;
        }

        // Show loading state
        resultDiv.textContent = "Checking...";
        resultDiv.className = "loading";
        checkBtn.disabled = true;

        // Send to background script
        chrome.runtime.sendMessage(
            {action: "checkURL", url: url},
            function(response) {
                checkBtn.disabled = false;
                
                if (chrome.runtime.lastError) {
                    resultDiv.textContent = "Extension error: " + chrome.runtime.lastError.message;
                    resultDiv.className = "error";
                    return;
                }

                if (response.error) {
                    resultDiv.textContent = "Error: " + response.error;
                    resultDiv.className = "error";
                    return;
                }

                // Display results
                if (response.isPhishing) {
                    resultDiv.innerHTML = `⚠️ <strong>Phishing Detected!</strong><br>Confidence: ${Math.round(response.confidence * 100)}%`;
                    resultDiv.className = "phishing";
                } else {
                    resultDiv.innerHTML = `✅ <strong>Safe URL</strong><br>Confidence: ${Math.round(response.confidence * 100)}%`;
                    resultDiv.className = "safe";
                }
            }
        );
    });
});