// Monitor all links on the page
document.addEventListener('DOMContentLoaded', () => {
  const links = document.getElementsByTagName('a');
  
  Array.from(links).forEach(link => {
    link.addEventListener('mouseover', (e) => {
      chrome.runtime.sendMessage(
        { action: "checkURL", url: e.target.href },
        (response) => {
          if (response.isPhishing) {
            e.target.style.border = '2px solid red';
            e.target.title = `⚠️ Warning: ${(response.confidence * 100).toFixed(1)}% phishing risk`;
          }
        }
      );
    });
  });
});